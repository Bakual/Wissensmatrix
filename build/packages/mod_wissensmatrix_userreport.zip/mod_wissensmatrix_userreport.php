<?php
/**
 * @package     Wissensmatrix
 * @subpackage  mod_wissensmatrix_userreport
 *
 * @copyright   Copyright (C) 2013 Thomas Hunziker
 * @license     GNU General Public License version 2
 */

defined('_JEXEC') or die;

require JModuleHelper::getLayoutPath('mod_wissensmatrix_userreport', $params->get('layout', 'default'));
