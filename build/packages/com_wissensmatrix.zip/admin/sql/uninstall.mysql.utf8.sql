DROP TABLE IF EXISTS `#__wissensmatrix_mitarbeiter`;
DROP TABLE IF EXISTS `#__wissensmatrix_weiterbildung`;
DROP TABLE IF EXISTS `#__wissensmatrix_weiterbildunggruppe`;
DROP TABLE IF EXISTS `#__wissensmatrix_fachwissen`;
DROP TABLE IF EXISTS `#__wissensmatrix_fachwissengruppe`;
DROP TABLE IF EXISTS `#__wissensmatrix_mit_fwi`;
DROP TABLE IF EXISTS `#__wissensmatrix_mit_wbi`;
