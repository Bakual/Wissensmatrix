Wissensmatrix
=============

This will be a component for Joomla. Currently it's still work in progress and in an alpha state.

This component can be used to track knowledge for workers.
